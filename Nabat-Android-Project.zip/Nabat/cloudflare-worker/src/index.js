const SYSTEM_INSTRUCTION = `أنت Nabat، مساعد ذكاء اصطناعي متخصص حصرياً في الزراعة باللغة العربية الواضحة. أجب بشكل عملي ومنظم، واهتم بالمحاصيل والنباتات والتربة والري والتسميد والطقس الزراعي والآفات وأمراض النباتات. إذا كان السؤال خارج نطاق الزراعة فاعتذر بلطف واطلب سؤالاً زراعياً. عند تحليل صورة، صف ما تراه واذكر الاحتمالات دون الجزم بتشخيص نهائي، واطلب معلومات إضافية مثل المحصول والمنطقة وعمر النبات عند الحاجة. لا تقدم وصفات خلط أو جرعات أو تعليمات تطبيق تفصيلية للمبيدات أو المواد الكيميائية الزراعية الخطرة؛ وجّه المستخدم إلى مهندس زراعي مختص وإلى الملصق الرسمي المحلي. لا تخترع بيانات أو تشخيصات.`;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}

async function sha256(value) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function enforceDailyLimit(request, env) {
  // KV is required so one visitor cannot freely consume the owner's API quota.
  if (!env.NABAT_LIMITS) throw new Error("Missing KV binding NABAT_LIMITS");
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const day = new Date().toISOString().slice(0, 10);
  const key = `daily:${day}:${(await sha256(ip)).slice(0, 24)}`;
  const current = Number((await env.NABAT_LIMITS.get(key)) || "0");
  const limit = Number(env.DAILY_REQUEST_LIMIT || 35);
  if (current >= limit) return false;
  await env.NABAT_LIMITS.put(key, String(current + 1), { expirationTtl: 60 * 60 * 48 });
  return true;
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/health") {
      return json({ ok: true, service: "Nabat API", version: "1.0.0" });
    }
    if (request.method !== "POST" || url.pathname !== "/api/chat") {
      return json({ error: "المسار غير موجود." }, 404);
    }
    if (!env.GEMINI_API_KEY) return json({ error: "لم يتم ضبط مفتاح الذكاء الاصطناعي على الخادم بعد." }, 503);
    const length = Number(request.headers.get("content-length") || 0);
    if (length > 7_000_000) return json({ error: "حجم الطلب كبير جداً. اختر صورة أصغر." }, 413);

    try {
      const allowed = await enforceDailyLimit(request, env);
      if (!allowed) return json({ error: "وصلت إلى الحد اليومي المجاني لهذا الجهاز. حاول غداً." }, 429);
      const input = await request.json();
      const prompt = String(input.prompt || "").slice(0, 6000);
      if (!prompt && !input.imageBase64) return json({ error: "اكتب سؤالك أو أرفق صورة نبات." }, 400);

      const contents = [];
      const history = Array.isArray(input.history) ? input.history.slice(-12) : [];
      for (const item of history) {
        const role = item?.role === "model" ? "model" : "user";
        const text = String(item?.text || "").slice(0, 5000);
        if (text) contents.push({ role, parts: [{ text }] });
      }
      const parts = [];
      if (prompt) parts.push({ text: prompt });
      if (input.imageBase64) {
        const image = String(input.imageBase64);
        if (image.length > 5_500_000) return json({ error: "الصورة كبيرة جداً. اختر صورة أصغر." }, 413);
        parts.push({ inlineData: { mimeType: "image/jpeg", data: image } });
      }
      contents.push({ role: "user", parts });

      const model = env.GEMINI_MODEL || "gemini-2.5-flash";
      const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(env.GEMINI_API_KEY)}`;
      const upstream = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
          contents,
          generationConfig: { temperature: 0.55, maxOutputTokens: 1800 },
        }),
      });
      const result = await upstream.json().catch(() => ({}));
      if (!upstream.ok) {
        console.error("Gemini upstream error", upstream.status, result?.error?.status || "unknown");
        return json({ error: "حدث خطأ في خدمة الذكاء الاصطناعي. حاول لاحقاً." }, 502);
      }
      const answer = (result.candidates?.[0]?.content?.parts || [])
        .map((part) => part.text || "")
        .join("")
        .trim();
      if (!answer) return json({ error: "لم تصل إجابة واضحة. حاول مرة أخرى." }, 502);
      return json({ answer });
    } catch (error) {
      console.error("Nabat worker error", error?.message || "unknown");
      if (String(error?.message).includes("Missing KV binding")) {
        return json({ error: "إعدادات حماية الخادم غير مكتملة. راجع إعداد NABAT_LIMITS في Cloudflare." }, 503);
      }
      return json({ error: "تعذر الاتصال حالياً. تحقق من الإنترنت وحاول مرة أخرى." }, 500);
    }
  },
};
