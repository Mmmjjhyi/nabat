# Nabat API — Cloudflare Worker

This Worker keeps the Gemini API key on the server. Never put `GEMINI_API_KEY` in the Android app, GitHub source, or a public GitHub Actions variable.

## Deploy once

1. Create a Cloudflare account and install Node.js on your computer.
2. Open a terminal in this folder (`cloudflare-worker`).
3. Run `npx wrangler login`.
4. Create the KV namespace:
   `npx wrangler kv namespace create NABAT_LIMITS`
5. Copy the returned namespace ID into `wrangler.toml`, replacing `REPLACE_WITH_YOUR_KV_NAMESPACE_ID`.
6. Add your Gemini key as an encrypted Worker secret:
   `npx wrangler secret put GEMINI_API_KEY`
   Paste the key when prompted. Do not put it in `wrangler.toml`.
7. Deploy:
   `npx wrangler deploy`
8. Cloudflare prints a URL similar to `https://nabat-api.YOUR-SUBDOMAIN.workers.dev`.
9. Check `https://YOUR-WORKER-URL/health`; it should return `{"ok":true,...}`.

## Connect the Android app

In the GitHub repository, open **Settings → Secrets and variables → Actions → Variables → New repository variable**.

- Name: `NABAT_API_BASE_URL`
- Value: your Worker base URL, for example `https://nabat-api.YOUR-SUBDOMAIN.workers.dev` (no trailing slash)

Then run the **Build Nabat Android APK** workflow again. The APK will connect to the Worker automatically; app users never enter an API key.

## Limits and production notes

- Default limit: 35 requests per IP address per UTC day. Adjust `DAILY_REQUEST_LIMIT` in `wrangler.toml` to change it.
- The Worker hashes the connecting IP before using it as a KV key; raw IP addresses are not stored by this code.
- The limit is a basic abuse barrier, not strong user authentication. For a public commercial release, add user accounts or app attestation, stricter rate controls, monitoring, and a spending budget at the AI provider.
- Cloudflare and Google AI service limits/pricing may change. Check their current dashboards before public launch.
