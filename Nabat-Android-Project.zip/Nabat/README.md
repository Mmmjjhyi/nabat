# Nabat 🌱 — Android + خادم ذكاء اصطناعي خاص

تطبيق Android عربي لمساعد زراعي بالذكاء الاصطناعي. هذه النسخة تستخدم خادماً وسيطاً على Cloudflare Workers؛ **مستخدم التطبيق لا يدخل أي API Key** ولا يوجد مفتاح Gemini داخل APK أو كود Android.

## ما الذي يتضمنه المشروع؟

- تطبيق Android مبني بـ Kotlin وJetpack Compose.
- واجهة عربية RTL بتصميم أخضر/أبيض ووضع داكن.
- محادثة زراعية وحفظ المحادثات النصية محلياً.
- إرفاق صورة نبات لتحليلها.
- خادم Cloudflare Worker يتصل بـ Gemini ويحفظ المفتاح كسِرّ خادمي.
- حماية أولية من إساءة الاستخدام عبر حد يومي لكل عنوان IP باستخدام Cloudflare KV (يتم تخزين hash فقط).
- GitHub Actions يبني APK ويرفعه كـ Artifact.

---

# الجزء الأول: نشر خادم Nabat (مرة واحدة)

تحتاج حساب Cloudflare ومفتاح Gemini. لا تضع مفتاح Gemini في تطبيق Android أو مستودع GitHub.

### 1) إنشاء Gemini API Key

أنشئ المفتاح من Google AI Studio: https://aistudio.google.com/app/apikey

### 2) إنشاء Cloudflare Worker

1. افتح https://dash.cloudflare.com وسجّل الدخول.
2. ثبّت Node.js على الكمبيوتر من https://nodejs.org (إذا لم يكن مثبتاً).
3. افتح Terminal / PowerShell داخل مجلد `cloudflare-worker` الموجود بالمشروع.
4. نفّذ:

```bash
npx wrangler login
```

5. أنشئ مساحة KV لحماية حد الاستخدام:

```bash
npx wrangler kv namespace create NABAT_LIMITS
```

6. سيظهر لك Namespace ID. افتح `cloudflare-worker/wrangler.toml` واستبدل النص `REPLACE_WITH_YOUR_KV_NAMESPACE_ID` بالـ ID الذي ظهر لك.
7. أضف مفتاح Gemini كسِرّ مشفّر على الخادم:

```bash
npx wrangler secret put GEMINI_API_KEY
```

الصق المفتاح عندما يطلبه منك. لن يظهر المفتاح داخل ملفات المشروع.

8. انشر الخادم:

```bash
npx wrangler deploy
```

9. سيظهر رابط شبيه بـ:

`https://nabat-api.YOUR-SUBDOMAIN.workers.dev`

افتح هذا الرابط مع `/health` في المتصفح. مثال:

`https://nabat-api.YOUR-SUBDOMAIN.workers.dev/health`

يجب أن ترى نتيجة JSON فيها `"ok":true`.

> إذا لم يكن لديك كمبيوتر، يمكن تنفيذ هذه الخطوات من واجهة Cloudflare على متصفح الكمبيوتر؛ نشر Wrangler من الطرفية هو المسار الأسهل والأوضح لهذا المشروع.

---

# الجزء الثاني: إعداد GitHub وبناء APK

1. أنشئ Repository جديداً على https://github.com.
2. ارفع **محتويات مجلد Nabat** إلى جذر المستودع، وليس ملف ZIP نفسه. يجب أن ترى `app/` و`cloudflare-worker/` و`.github/` و`build.gradle.kts` في الصفحة الرئيسية للمستودع.
3. في GitHub افتح المستودع ثم:
   **Settings → Secrets and variables → Actions → Variables → New repository variable**.
4. أضف المتغير التالي:
   - Name: `NABAT_API_BASE_URL`
   - Value: رابط Worker الذي حصلت عليه من Cloudflare، بدون `/health` وبدون شرطة `/` في النهاية.
   - مثال: `https://nabat-api.YOUR-SUBDOMAIN.workers.dev`
5. احفظ المتغير.
6. افتح تبويب **Actions**.
7. اختر **Build Nabat Android APK** ثم **Run workflow**.
8. بعد نجاح التشغيل، افتح نتيجة التشغيل وانزل إلى **Artifacts**.
9. حمّل `Nabat-debug-apk` وفك ضغطه؛ ستجد `app-debug.apk`.
10. ثبّت APK على هاتف Android. المستخدم النهائي لن يحتاج إلى إدخال API Key.

أي تعديل جديد على فرع `main` أو `master` سيشغّل البناء تلقائياً. بعد تغيير رابط Worker في GitHub Variables، أعد تشغيل الـ workflow لإنتاج APK بالرابط الجديد.

---

## تغيير حد الاستخدام

الحد الافتراضي هو 35 طلباً يومياً لكل عنوان IP. لتغييره عدّل `DAILY_REQUEST_LIMIT` في `cloudflare-worker/wrangler.toml` ثم نفّذ `npx wrangler deploy`.

## تنبيهات مهمة قبل النشر العام

- خادم Worker ومفتاح Gemini تحت سيطرتك، لكن استهلاك Gemini قد يترتب عليه رسوم أو حدود حسب حسابك وخطتك. راقب لوحة Google AI وCloudflare.
- حد KV اليومي حاجز أولي وليس نظام حسابات أو حماية كاملة من إساءة الاستخدام. قبل إطلاق تجاري واسع أضف تسجيل دخول/مصادقة ومراقبة وتحديد معدل أقوى وميزانية إنفاق.
- لا تضع `GEMINI_API_KEY` في GitHub Variables أو في ملفات المشروع. المفتاح يجب أن يبقى فقط في Cloudflare Worker Secrets.
- التطبيق يقدم إرشادات زراعية عامة، وليس بديلاً عن مهندس زراعي. التشخيص بالصور احتمالي، ويجب عدم الاعتماد عليه وحده في قرارات المكافحة أو استخدام المواد الكيميائية.

## معلومات تقنية

- Android application ID: `com.nabat.ai`
- Version: `1.1.0` (versionCode 2)
- Minimum Android: 7.0 (API 24)
- JDK: 17
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle: 8.9 (يضبطه GitHub Actions)
- Gemini model الافتراضي على الخادم: `gemini-2.5-flash`
