package com.nabat.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

private val Leaf = Color(0xFF248B52)
private val Pale = Color(0xFFEAF5ED)
private data class ChatMessage(val text: String, val fromUser: Boolean, val imageBase64: String? = null)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NabatApp() }
    }
}

@Composable
private fun NabatApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nabat", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var pickedImage by remember { mutableStateOf<Uri?>(null) }
    var imageBase64 by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val messages = remember {
        mutableStateListOf<ChatMessage>().apply {
            try {
                val saved = JSONArray(prefs.getString("messages", "[]") ?: "[]")
                for (i in 0 until saved.length()) {
                    val item = saved.getJSONObject(i)
                    add(ChatMessage(item.optString("text"), item.optBoolean("fromUser"), null))
                }
            } catch (_: Exception) { }
        }
    }
    val listState = rememberLazyListState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        pickedImage = uri
        imageBase64 = uri?.let { encodeImage(context, it) }
    }
    val scheme = if (dark) darkColorScheme(primary = Color(0xFF69C98B), background = Color(0xFF101713), surface = Color(0xFF18221C))
        else lightColorScheme(primary = Leaf, background = Color(0xFFF8FBF8), surface = Color.White)

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        LaunchedEffect(messages.size) {
            if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
        }
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Pale, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Eco, null, tint = Leaf, modifier = Modifier.size(27.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Nabat", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text("مساعدك الذكي في عالم الزراعة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { messages.clear(); prefs.edit().remove("messages").apply(); pickedImage = null; imageBase64 = null }) { Icon(Icons.Default.DeleteOutline, "محادثة جديدة") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "الإعدادات") }
                }
                if (messages.isEmpty()) {
                    Column(Modifier.weight(1f).fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(Modifier.size(88.dp).background(Pale, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Eco, null, tint = Leaf, modifier = Modifier.size(54.dp)) }
                        Spacer(Modifier.height(18.dp))
                        Text("أهلاً بك في Nabat 🌱", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Spacer(Modifier.height(8.dp))
                        Text("اسأل عن المحاصيل والري والتربة والتسميد وأمراض النباتات.", color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 23.sp)
                        Spacer(Modifier.height(24.dp))
                        listOf("كيف أعتني بالطماطم؟", "ما أسباب اصفرار أوراق النبات؟", "ما أفضل طريقة لتحسين التربة؟").forEach { suggestion ->
                            Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { input = suggestion }, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 1.dp) {
                                Text(suggestion, Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), state = listState, contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(messages) { msg ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.Start else Arrangement.End) {
                                Surface(color = if (msg.fromUser) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp), tonalElevation = 1.dp, modifier = Modifier.widthIn(max = 320.dp)) {
                                    Text(msg.text, Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onSurface, lineHeight = 23.sp)
                                }
                            }
                        }
                        if (busy) item { Text("Nabat يجهز الإجابة...", color = Leaf, modifier = Modifier.padding(8.dp)) }
                    }
                }
                Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(12.dp)) {
                    if (pickedImage != null) Text("تم اختيار صورة للتحليل", color = Leaf, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp, bottom = 5.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { picker.launch("image/*") }) { Icon(Icons.Default.AddPhotoAlternate, "إرفاق صورة", tint = Leaf) }
                        OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("اسأل Nabat عن الزراعة...") }, shape = RoundedCornerShape(24.dp), maxLines = 4)
                        Spacer(Modifier.width(7.dp))
                        FilledIconButton(onClick = {
                            val prompt = input.trim()
                            if ((prompt.isNotEmpty() || imageBase64 != null) && !busy) {
                                run {
                                    val img = imageBase64
                                    messages.add(ChatMessage(if (prompt.isBlank()) "حلّل الصورة المرفقة" else prompt, true, img))
                                    val savedBeforeReply = JSONArray()
                                    messages.forEach { m -> savedBeforeReply.put(JSONObject().put("text", m.text).put("fromUser", m.fromUser)) }
                                    prefs.edit().putString("messages", savedBeforeReply.toString()).apply()
                                    input = ""; imageBase64 = null; pickedImage = null; busy = true
                                    scope.launch {
                                        val answer = withContext(Dispatchers.IO) { NabatClient.ask(messages.toList().dropLast(1), prompt.ifBlank { "حلّل النبات في الصورة، واذكر الملاحظات والاحتمالات والخطوات الآمنة التالية." }, img) }
                                        messages.add(ChatMessage(answer, false)); busy = false
                                        val saved = JSONArray()
                                        messages.forEach { m -> saved.put(JSONObject().put("text", m.text).put("fromUser", m.fromUser)) }
                                        prefs.edit().putString("messages", saved.toString()).apply()
                                        listState.animateScrollToItem(messages.size - 1)
                                    }
                                }
                            }
                        }, enabled = !busy) { Icon(Icons.Default.ArrowUpward, "إرسال") }
                    }
                    Text("Nabat يقدم إرشادات عامة؛ تحقّق من التشخيص والجرعات محلياً قبل التطبيق.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp))
                }
            }
        }
        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("إعدادات Nabat") },
            text = { Column {
                Text("إعدادات التطبيق", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Text("الوضع الداكن", Modifier.weight(1f)); Switch(checked = dark, onCheckedChange = { dark = it; prefs.edit().putBoolean("dark", it).apply() }) }
                Text("Nabat متصل بخادم الذكاء الاصطناعي. لا يحتاج المستخدم إلى إدخال أي مفتاح API.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("تم") } }
        )
        }
    }
}

private fun encodeImage(context: Context, uri: Uri): String? = try {
    val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
    val scaled = Bitmap.createScaledBitmap(bitmap, minOf(bitmap.width, 1200), (bitmap.height * (minOf(bitmap.width, 1200).toFloat() / bitmap.width)).toInt().coerceAtLeast(1), true)
    val out = ByteArrayOutputStream(); scaled.compress(Bitmap.CompressFormat.JPEG, 78, out)
    android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
} catch (_: Exception) { null }

private object NabatClient {
    private val client = OkHttpClient.Builder().callTimeout(100, TimeUnit.SECONDS).build()
    fun ask(history: List<ChatMessage>, prompt: String, image: String?): String {
        return try {
            val baseUrl = BuildConfig.NABAT_API_BASE_URL.trim().trimEnd('/')
            if (baseUrl.isBlank() || baseUrl.contains("YOUR-WORKER")) return "خادم Nabat لم يتم ضبط عنوانه بعد. أكمل نشر Cloudflare Worker ثم أضف NABAT_API_BASE_URL في GitHub Variables وأعد البناء."
            val historyJson = JSONArray()
            history.takeLast(12).forEach { m ->
                historyJson.put(JSONObject().put("role", if (m.fromUser) "user" else "model").put("text", m.text))
            }
            val body = JSONObject().put("history", historyJson).put("prompt", prompt)
            if (image != null) body.put("imageBase64", image)
            val request = Request.Builder().url("$baseUrl/api/chat")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                val json = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
                if (!response.isSuccessful) json.optString("error", "تعذر الاتصال بخادم Nabat (${response.code}).")
                else json.optString("answer").ifBlank { "لم أتمكن من استخراج إجابة. حاول مرة أخرى." }
            }
        } catch (e: Exception) { "تعذر الاتصال بخادم Nabat: ${e.localizedMessage ?: "تحقق من الإنترنت"}" }
    }
}
